package com.example.recopilacionandroid.data

import com.example.recopilacionandroid.model.Car

object Datasource {

    val colores = listOf(
        "Red", "Green", "Blue", "Yellow", "Orange",
        "Purple", "Pink", "Brown", "Gray", "Black",
        "White", "Cyan", "Magenta", "Lime", "Teal",
        "Indigo", "Violet", "Silver", "Gold", "Beige"
    )

    val marcas = listOf(
         "Chevrolet", "Volkswagen",
        "Subaru","Land Rover", "Jaguar",
        "MG","Skoda","Maserati","Smart","Opel"
    )
    val carList: List<Car> = listOf(
        Car(1, marcas.random(), colores.random(), "Camry", 50000, true),
        Car(2, marcas.random(), colores.random(), "Civic", 25000, false),
        Car(3, marcas.random(), colores.random(), "Mustang", 10000, true),
        Car(4, marcas.random(), colores.random(), "Cruze", 30000, false),
        Car(5, marcas.random(), colores.random(), "Altima", 40000, true),
        Car(6, marcas.random(), colores.random(), "3 Series", 60000, false)
    )
}
package com.example.recopilacionandroid.navigation

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.recopilacionandroid.R
import com.example.recopilacionandroid.data.Datasource.carList
import com.example.recopilacionandroid.model.Car
import kotlin.text.toIntOrNull


@Composable
fun AddCarScreen( navController: NavController, onAddCar: (Car) -> Unit) {
    Scaffold(
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top, // Or Arrangement.SpaceBetween
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Add Car Screen", fontSize = 32.sp)
            CarForm (context = navController.context){ car ->
                onAddCar(car)
                navController.popBackStack()
                Log.d("Coche Creado", "Coche creado:"+ car.toString())
            // Navigate back after submitting
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CarForm(context: Context, onAddCar: (Car) -> Unit) {
    var brand by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var km by remember { mutableStateOf(0) }
    var onSale by remember { mutableStateOf(true) }

    val brandOptions: Array<String> = context.resources.getStringArray(R.array.car_brands)
    val colorOptions : Array<String> = context.resources.getStringArray(R.array.car_colors)

    // Variables para controlar la expansión del menú desplegable
    var brandExpanded by remember { mutableStateOf(false) }
    var colorExpanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        // Dropdown para seleccionar la marca
        ExposedDropdownMenuBox(
            expanded = brandExpanded,
            onExpandedChange = { brandExpanded = !brandExpanded }
        ) {
            OutlinedTextField(
                value = brand,
                onValueChange = { brand = it },
                label = { Text(stringResource(R.string.brand)) },
                readOnly = true, // Para evitar la edición manual
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = brandExpanded)
                },
                modifier = Modifier
                    .menuAnchor() // Esto asegura que el menú se alinee correctamente
            )

            ExposedDropdownMenu(
                expanded = brandExpanded,
                onDismissRequest = { brandExpanded = false }
            ) {
                brandOptions.forEach { selectionOption ->
                    DropdownMenuItem(
                        text = { Text(selectionOption) },
                        onClick = {
                            brand = selectionOption
                            brandExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dropdown para seleccionar el color
        ExposedDropdownMenuBox(
            expanded = colorExpanded,
            onExpandedChange = { colorExpanded = !colorExpanded }
        ) {
            OutlinedTextField(
                value = color,
                onValueChange = { color = it },
                label = { Text(stringResource(R.string.color)) },
                readOnly = true, // Para evitar la edición manual
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = colorExpanded)
                },
                modifier = Modifier
                    .menuAnchor() // Esto asegura que el menú se alinee correctamente
            )

            ExposedDropdownMenu(
                expanded = colorExpanded,
                onDismissRequest = { colorExpanded = false }
            ) {
                colorOptions.forEach { selectionOption ->
                    DropdownMenuItem(
                        text = { Text(selectionOption) },
                        onClick = {
                            color = selectionOption
                            colorExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Campo para el modelo
        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            label = { Text(stringResource(R.string.model)) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Campo para los kilómetros
        OutlinedTextField(
            value = km.toString(),
            onValueChange = { km = it.toIntOrNull() ?: 0 },
            label = { Text(stringResource(R.string.km)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Checkbox para indicar si el carro está en venta
        Row (horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically){
            Checkbox(
                checked = onSale,
                onCheckedChange = { onSale = it }
            )
            Text(stringResource(R.string.onSale))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón de enviar
        Button(onClick = { onAddCar(Car((carList.size + 1), brand, color, model, km, onSale)) }) { // Suponiendo que el id se genera automáticamente
            Text(stringResource(R.string.add))
        }
    }
}


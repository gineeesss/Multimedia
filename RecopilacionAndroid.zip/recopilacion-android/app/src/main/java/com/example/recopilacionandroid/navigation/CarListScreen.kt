package com.example.recopilacionandroid.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.recopilacionandroid.R
import com.example.recopilacionandroid.model.Car
import com.example.recopilacionandroid.viewmodel.Viewmodel

@Composable
fun CarListScreen(onNavSelected: (String) -> Unit, carList: List<Car>,viewmodel: Viewmodel) {
    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = stringResource(R.string.lst_cars), fontSize = 30.sp)
        Spacer(Modifier.padding(20.dp))
        Text(text = stringResource(R.string.carsCount, carList.size))
        Spacer(Modifier.padding(20.dp))

        // Botón para añadir coches
        OutlinedButton(onClick = { onNavSelected("AddCarScreen") }) {
            Text(stringResource(R.string.btn_AddCar))
        }

        // Botón para añadir coches aleatorios
        OutlinedButton(onClick = { viewmodel.addRandomCar() }) {
            Text(stringResource(R.string.addRndCar))
        }

        Spacer(Modifier.padding(2.dp))

        ListaLazyNombre(
            onNavSelected = { car -> onNavSelected("CarSpecs/${car.id}") },
            carList,
            viewmodel
        )
    }
}

@Composable
fun ListaLazyNombre(onNavSelected: (Car) -> Unit, carList: List<Car>,viewmodel: Viewmodel) {
    LazyColumn {
        items(items = carList) { car ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                border = BorderStroke(1.dp, Color.Black),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                CardItem(car, {onNavSelected(car) },viewmodel )
            }
        }
    }
}

@Composable
fun CardItem(car: Car, onNavSelected: () -> Unit,viewmodel: Viewmodel) {
    val colorMap: Map<String, Color> = mapOf(
        "Red" to Color(255, 0, 0),      // Red
        "Blue" to Color(0, 0, 255),     // Blue
        "Green" to Color(0, 255, 0),    // Green
        "Black" to Color(0, 0, 0),      // Black
        "White" to Color(255, 255, 255),// White
        "Yellow" to Color(255, 255, 0), // Yellow
        "Orange" to Color(255, 165, 0), // Orange
        "Purple" to Color(128, 0, 128), // Purple
        "Pink" to Color(255, 192, 203), // Pink
        "Brown" to Color(165, 42, 42),  // Brown
        "Gray" to Color(128, 128, 128)  // Gray
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            painter = painterResource(id = R.drawable.car),
            contentDescription = "Icono",
            modifier = Modifier
                .size(64.dp)
                .clickable { },
            //tint = Color(0, 0, 220)
            tint = colorMap[car.color] ?: Color.Black
            )
        Column {
            Text(car.brand, modifier = Modifier.padding(6.dp, 4.dp))
            Text(car.model + " " + car.color, modifier = Modifier.padding(6.dp, 0.dp))
        }
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(6.dp, 0.dp), horizontalAlignment = Alignment.End
            ) {
                Button(onClick = onNavSelected) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "Information",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                // Botón para eliminar coche
                Button(onClick = {
                    viewmodel.removeCar(car)
                }) {
                    Icon(
                        painter = painterResource(id = R.drawable.papelera),
                        contentDescription = "eliminar",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )

                }

            }

        }


    }
}

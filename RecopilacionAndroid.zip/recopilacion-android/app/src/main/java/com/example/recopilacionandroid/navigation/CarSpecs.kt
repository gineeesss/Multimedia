package com.example.recopilacionandroid.navigation


import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.recopilacionandroid.R
import com.example.recopilacionandroid.model.Car
import java.util.Locale

@Composable
fun CarSpecs(car: Car, onBackPressed: () -> Unit) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.carDetails),
            style = MaterialTheme.typography.headlineMedium,
            fontSize = 24.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)

        ) {
            Row (modifier=Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically){
                Column (){
                    Icon(
                        painter = painterResource(
                            when (car.brand.lowercase()) {

                            "chevrolet" -> R.drawable.chevrolet
                            "volkswagen" -> R.drawable.volkswagen
                            "subaru" -> R.drawable.subaru
                            "land rover" -> R.drawable.land_rover
                            "jaguar" -> R.drawable.jaguar
                                "mg" -> R.drawable.mg
                            "skoda" -> R.drawable.skoda
                            "maserati" -> R.drawable.maserati
                            "smart" -> R.drawable.smart
                            "opel" -> R.drawable.opel
                            else -> R.drawable.car // Un logo por defecto si la marca no coincide
                        }
                        ),
                        contentDescription = "logo del coche",
                        modifier = Modifier.size(100.dp)
                    )
                }
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.brandExtract, car.brand), style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = stringResource(R.string.modelExtract, car.model), style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = stringResource(R.string.colorExtract, car.color), style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = stringResource(R.string.kmExtract, car.km), style = MaterialTheme.typography.bodyMedium)
                }            }

        }

        Spacer(modifier = Modifier.height(20.dp))

        // Botón para regresar
        Button(onClick = onBackPressed) {
            Text(text = stringResource(R.string.back))
        }

        // Botón para navegar en internet

        var url = Uri.parse("https://www.google.es/search?tbm=isch&q="+car.brand+" "+car.model+" "+car.color+" del año "+ calcularAnioCoche(car.km))
        ElevatedButton(onClick = { openBrowser(context,url.toString()) }) {
            Text(stringResource(R.string.searchWWW))
        }
    }
}
fun calcularAnioCoche(km: Int):Int{
    val anio=km/15000
    return 2024-anio
}

fun openBrowser(context: Context, url: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    context.startActivity(intent)
}


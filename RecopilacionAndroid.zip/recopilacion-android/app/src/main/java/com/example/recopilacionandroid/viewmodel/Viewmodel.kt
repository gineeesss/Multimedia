package com.example.recopilacionandroid.viewmodel


import androidx.lifecycle.ViewModel
import com.example.recopilacionandroid.data.Datasource
import com.example.recopilacionandroid.model.Car
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class Viewmodel : ViewModel() {
    private val _carList = MutableStateFlow(Datasource.carList)
    val carList: StateFlow<List<Car>> = _carList.asStateFlow()


    //logica de negocio del view model
    fun addCar(car: Car) {
        _carList.value += car
    }

    fun removeCar(car: Car) {
        _carList.value -= car
    }


    fun addRandomCar() {
        val newCar = Car(
            id = _carList.value.size + 1,
            brand = Datasource.marcas.random(),
            color = Datasource.colores.random(),
            model = "Modelo",
            km = (0..100000).random(),
            onSale = true
        )
        _carList.value += newCar



    }







}
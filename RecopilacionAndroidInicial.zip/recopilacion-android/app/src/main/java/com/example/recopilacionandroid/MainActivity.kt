package com.example.recopilacionandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.recopilacionandroid.navigation.MainTopBar
import com.example.recopilacionandroid.navigation.NavigationMain
import com.example.recopilacionandroid.ui.theme.RecopilacionAndroidTheme
import com.example.recopilacionandroid.viewmodel.Viewmodel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RecopilacionAndroidTheme {
                Scaffold(
                    modifier = Modifier.fillMaxWidth()) {
                    innerPadding ->
                    Column(modifier = Modifier.padding(innerPadding)) {
                        HorizontalDivider()
                    App(

                    )
                }
                }
            }
        }
    }
}


@Composable
fun App() {
    NavigationMain()

}

@Preview(showBackground = true)
@Composable
fun AppPreview() {
    RecopilacionAndroidTheme {
        App()
    }
}
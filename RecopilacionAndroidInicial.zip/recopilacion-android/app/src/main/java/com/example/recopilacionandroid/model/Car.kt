package com.example.recopilacionandroid.model

data class Car(
    val id: Int,
    val brand: String,
    val color: String,
    val model: String,
    val km: Int = 0,
    val onSale: Boolean = true,
) {
    override fun toString(): String {
        return "Car(id=$id, brand='$brand', color='$color', model='$model', km=$km, onSale=$onSale)"
    }
}
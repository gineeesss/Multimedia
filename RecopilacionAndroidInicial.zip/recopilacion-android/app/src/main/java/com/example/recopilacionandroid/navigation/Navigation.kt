package com.example.recopilacionandroid.navigation

import MainScreen
import android.util.Log
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.recopilacionandroid.viewmodel.Viewmodel

sealed class Destinations(val route: String){
    object MainScreen : Destinations("MainScreen")
    object CardListScreen : Destinations("CardListScreen")
    object AddCarScreen : Destinations("AddCarScreen")
}
@Composable
fun NavigationMain() {
    val navController = rememberNavController()
    val viewmodel = Viewmodel()
    val carList by viewmodel.carList.collectAsState()

    NavHost(navController = navController, startDestination = "MainScreen"){
        composable(Destinations.MainScreen.route) {

            MainScreen(onNavSelected = {dest -> navController.navigate(dest)},carList)
            MainTopBar(onNavSelected = { dest -> navController.navigate(dest) })

        }
        composable(Destinations.CardListScreen.route) {
            CarListScreen(onNavSelected = { dest -> navController.navigate(dest) }, carList,viewmodel)
            MainTopBar(onNavSelected = { dest -> navController.navigate(dest) })
        }
        composable(Destinations.AddCarScreen.route) {
            AddCarScreen(navController, onAddCar = { car -> viewmodel.addCar(car)
                Log.d("Coche Creado", "Coche creado:"+ car.toString())
            })
            MainTopBar(onNavSelected = { dest -> navController.navigate(dest) })

        }
        composable("CarSpecs/{carId}") { backStackEntry ->
            val carId = backStackEntry.arguments?.getString("carId")
            // Encuentra el coche en la lista
            val car = carList.find { it.id.toString() == carId }
            if (car != null) {
                CarSpecs(car = car, onBackPressed = { navController.popBackStack() })
            } else {
                Text("Coche no encontrado.")
            }
        }
    }
}

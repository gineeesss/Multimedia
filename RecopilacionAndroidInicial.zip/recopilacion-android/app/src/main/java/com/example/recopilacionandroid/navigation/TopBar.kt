package com.example.recopilacionandroid.navigation

import android.content.Context
import android.widget.Space
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.recopilacionandroid.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTopBar(onNavSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) } // Estado para controlar el menú

    TopAppBar(
        colors = topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            titleContentColor = Color.Blue
        ),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(R.drawable.car),
                    contentDescription = "Menu Icon",
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.title),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Left
                )

                // Usamos un Box para contener el IconButton y el DropdownMenu
                Box {
                    IconButton(onClick = { expanded = !expanded }) {
                        Icon(
                            imageVector = Icons.Filled.Menu,
                            contentDescription = stringResource(R.string.menu),
                            tint = Color.Blue,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Aquí colocamos el DropdownMenu
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.home)) },
                            onClick = {
                                onNavSelected("MainScreen")
                                expanded = false // Cerrar el menú al seleccionar
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.lst_cars))},
                            onClick = {
                                onNavSelected("CardListScreen")
                                expanded = false // Cerrar el menú al seleccionar
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.btn_AddCar))},
                            onClick = {
                                onNavSelected("AddCarScreen")
                                expanded = false // Cerrar el menú al seleccionar
                            }
                        )
                    }
                }

                Spacer(Modifier.padding(0.dp, 0.dp, 12.dp, 0.dp))
            }
        }
    )
}
